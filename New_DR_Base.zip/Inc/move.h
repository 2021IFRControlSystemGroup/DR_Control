#ifndef __MOVE_H__
#define __MOVE_H__

#include "main.h"
#include "math.h"
#include "robo_base.h"
#include "analysis.h"

void Move_Analysis(void);
void Motor_Angle(Motor_Group* P_Motor,double dA_Tar);

#endif


